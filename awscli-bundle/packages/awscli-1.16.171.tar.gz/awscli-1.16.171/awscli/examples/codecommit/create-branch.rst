**To create a branch**

This example creates a branch in an AWS CodeCommit repository. This command produces output only if there are errors.

Command::

  aws codecommit create-branch --repository-name MyDemoRepo --branch-name MyNewBranch --commit-id 317f8570EXAMPLE

Output::

  None.
