**To delete custom metadata from a resource**

This example deletes all custom metadata from the specified resource.

Command::

  aws workdocs delete-custom-metadata --resource-id d90d93c1fe44bad0c8471e973ebaab339090401a95e777cffa58e977d2983b65 --delete-all

Output::

  None